package parser;

public class RecursiveDescentParser {
    private String expressionString;
    private int indexInEquation = 0;

    public RecursiveDescentParser(String expressionString) {
        this.expressionString = expressionString;
        this.indexInEquation = 0;
    }

    public TreeNode proc_E() {
        TreeNode leftNode = null, rightNode = null;
        leftNode = proc_T();

        while (indexInEquation < expressionString.length() && expressionString.charAt(indexInEquation) == '+') {
            this.indexInEquation++;
            rightNode = proc_T();

            if (rightNode == null)
                return null;

            leftNode = new TreeNode('+', leftNode, rightNode);
        }
        return leftNode;
    }

    public TreeNode proc_T() {
        TreeNode leftNode = null, rightNode = null;
        leftNode = proc_V();

        while (indexInEquation < expressionString.length() && expressionString.charAt(indexInEquation) == '*') {
            this.indexInEquation++;
            rightNode = proc_V();

            if (rightNode == null)
                return null;

            leftNode = new TreeNode('*', leftNode, rightNode);
        }
        return leftNode;
    }

    public TreeNode proc_V() {
        if (indexInEquation < expressionString.length() && expressionString.charAt(indexInEquation) != '*'
                && expressionString.charAt(indexInEquation) != '+')
            return new TreeNode(expressionString.charAt(indexInEquation++), null, null);

        else {
            System.out.println("\nInvalid Expression!");
            return null;
        }
    }
}